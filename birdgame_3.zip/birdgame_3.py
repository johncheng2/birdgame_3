import pygame
import random
import sys
import math
import json
from pathlib import Path

pygame.init()

WIDTH = 900
HEIGHT = 600
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SKY = (135, 206, 235)
GRASS = (34, 139, 34)
YELLOW = (255, 215, 0)
RED = (220, 20, 60)
BLUE = (65, 105, 225)
GREEN = (0, 200, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bird Game 3")

clock = pygame.time.Clock()
FONT = pygame.font.Font(None, 32)
BIG_FONT = pygame.font.Font(None, 64)

# bow image
BOW_PNG_RAW = pygame.image.load("bow.png").convert_alpha()
# scale here if needed
BOW_PNG = pygame.transform.scale(BOW_PNG_RAW, (260, 240))

BIRD_PNG = { "pigeon": pygame.image.load("pigeon.png").convert_alpha(), "hummingbird": pygame.image.load("hummingbird.png").convert_alpha(),
            "eagle": pygame.image.load("eagle.png").convert_alpha()}

for key in BIRD_PNG:
    img = BIRD_PNG[key]
    # scale here if needed
    BIRD_PNG[key] = pygame.transform.scale(img, (180, 140))

#arrow image
ARROW_PNG_RAW = pygame.image.load("arrow.png").convert_alpha()

# scale here if needed
ARROW_PNG = pygame.transform.scale(ARROW_PNG_RAW, (120, 100))

leaderboard_file = Path("leaderboard.json")

# leaderboard

def load_leaderboard():
    if leaderboard_file.exists():
        try:
            return json.loads(leaderboard_file.read_text())
        except Exception:
            return []
    return []


def save_leaderboard(board):
    leaderboard_file.write_text(json.dumps(board, indent=2))


leaderboard = load_leaderboard()


def update_leaderboard(name, score):
    global leaderboard
    leaderboard.append({"name": name, "score": score})
    leaderboard = sorted(leaderboard, key=lambda d: d["score"], reverse=True)[:3]
    save_leaderboard(leaderboard)


# classes

class Player:
    def __init__(self):
        # position of bow
        self.x = WIDTH // 2
        self.y = HEIGHT - 80
        self.speed = 7

        self.base_image = BOW_PNG
        self.image = self.base_image
        self.rect_obj = self.image.get_rect(center=(self.x, self.y))

    def rect(self):
        return self.rect_obj

    def move(self, keys):
        if keys[pygame.K_LEFT]:
            self.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.x += self.speed
        self.x = max(self.rect_obj.width // 2,
                     min(WIDTH - self.rect_obj.width // 2, self.x))

    def rotate_aim(self):
        mx, my = pygame.mouse.get_pos()
        dx = mx - self.x
        dy = my - self.y

        angle = -math.degrees(math.atan2(dy, dx)) -90

        self.image = pygame.transform.rotate(self.base_image, angle)
        self.rect_obj = self.image.get_rect(center=(self.x, self.y))

    def draw(self, surf):
        # Update rotation before drawing
        self.rotate_aim()
        surf.blit(self.image, self.rect_obj)


class Arrow:
    def __init__(self, x, y, target, wind):
        self.x = x
        self.y = y
        self.speed = 13

        tx, ty = target
        dx, dy = tx - x, ty - y
        length = (dx ** 2 + dy ** 2) ** 0.5 or 1
        self.vx = (dx / length) * self.speed + wind * 4
        self.vy = (dy / length) * self.speed
        self.alive = True

        self.base_image = ARROW_PNG
        
        angle = -math.degrees(math.atan2(self.vy, self.vx)) -90
        self.image = pygame.transform.rotate(self.base_image, angle)
        self.rect_obj = self.image.get_rect(center=(self.x, self.y))

    def update(self):
        self.x += self.vx
        self.y += self.vy

        self.rect_obj = self.image.get_rect(center=(self.x, self.y))

        if (self.x < -50 or self.x > WIDTH + 50 or
                self.y < -50 or self.y > HEIGHT + 50):
            self.alive = False

    def rect(self):
        return self.rect_obj

    def draw(self, surf):
        surf.blit(self.image, self.rect_obj)


class Bird:
    TYPES = {
        "pigeon": {"speed": 4, "points": 10},
        "hummingbird": {"speed": 10, "points": 20},
        "eagle": {"speed": 5, "points": 50},
    }

    def __init__(self, bird_type, direction, wind):
        self.bird_type = bird_type
        data = Bird.TYPES[bird_type]

        self.speed = data["speed"]
        self.points = data["points"]
        self.direction = direction   # 1 = moving RIGHT, -1 = moving LEFT
        self.wind = wind
        self.alive = True

        # load sprite
        self.base_image = BIRD_PNG[bird_type]                  # faces LEFT
        self.flipped_image = pygame.transform.flip(self.base_image, True, False)  # faces RIGHT

        self.image = self.base_image

        self.width = self.image.get_width()
        self.height = self.image.get_height()

        if self.direction == 1:      # starting offscreen left
            self.x = -80
        else:                        # starting offscreen right
            self.x = WIDTH + 80

        self.y = random.randint(60, HEIGHT // 2)

    def rect(self):
        # the hitbox of birds
        full = self.image.get_rect(center=(self.x, self.y))
        hitbox = full.inflate(-full.width * 0.99, -full.height * 0.99)
        return hitbox

    def update(self):
        self.x += self.direction * self.speed + self.wind * 0.5
        self.y += random.randint(-1, 1)

        if self.direction == 1 and self.x > WIDTH + 120:
            self.alive = False
        if self.direction == -1 and self.x < -120:
            self.alive = False

    def draw(self, surf):

        if self.direction == 1:
            self.image = self.flipped_image
        else:
            self.image = self.base_image

        rect = self.image.get_rect(center=(self.x, self.y))
        surf.blit(self.image, rect)

# gui

STATE_MENU = "menu"
STATE_PLAYING = "playing"
STATE_GAME_OVER = "game_over"
STATE_INSTRUCTIONS = "instructions"

start_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 20, 200, 50)
instructions_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 60, 200, 50)
restart_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 40, 200, 50)
back_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT - 90, 200, 50)


def draw_button(rect, text):
    pygame.draw.rect(screen, BLACK, rect, border_radius=8)
    pygame.draw.rect(screen, WHITE, rect.inflate(-4, -4), border_radius=8)
    label = FONT.render(text, True, BLACK)
    screen.blit(label, label.get_rect(center=rect.center))


def choose_bird_type(score):
    r = random.random()
    # You can tweak probabilities / score thresholds as you like
    if score > 150 and r < 0.15:
        return "eagle"
    if score > 50 and r < 0.3:
        return "hummingbird"
    if score > 25 and r < 0.2:
        return "hummingbird"
    return "pigeon"


def compute_spawn_interval(score):
    base = 1600
    reduction = min(1100, score * 4)
    return base - reduction


def maybe_change_wind(current_wind, elapsed_ms):
    if elapsed_ms % 2000 < 30:
        if random.random() < 0.15:
            current_wind = random.choice([-1, 0, 1])
    return current_wind


# main loop

def main():
    global leaderboard

    state = STATE_MENU
    player = Player()
    arrows = []
    birds = []
    score = 0
    running = True
    game_duration = 60_000  # ms
    start_time = 0
    last_spawn_time = 0
    wind = 0
    player_name = "hunter"

    while running:
        dt = clock.tick(FPS)
        current_time = pygame.time.get_ticks()

        # --- Event handling ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if state == STATE_MENU:
                    if start_button.collidepoint(event.pos):
                        state = STATE_PLAYING
                        score = 0
                        arrows.clear()
                        birds.clear()
                        start_time = current_time
                        last_spawn_time = current_time
                        wind = 0

                    elif instructions_button.collidepoint(event.pos):
                            state = STATE_INSTRUCTIONS

                elif state == STATE_INSTRUCTIONS:
                    if back_button.collidepoint(event.pos):
                        state = STATE_MENU

                elif state == STATE_PLAYING:
                    score -=2
                    arrows.append(Arrow(player.x, player.y, event.pos, wind))
                elif state == STATE_GAME_OVER:
                    if restart_button.collidepoint(event.pos):
                        state = STATE_MENU
                        player_name = "hunter"

            if state == STATE_GAME_OVER and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    name_to_save = player_name or "hunter"
                    update_leaderboard(name_to_save, score)
                    state = STATE_MENU
                elif event.key == pygame.K_BACKSPACE and len(player_name) > 0:
                    player_name = player_name[:-1]
                elif len(player_name) < 8 and event.unicode.isprintable() and not event.key in (pygame.K_RETURN, pygame.K_BACKSPACE):
                    player_name += event.unicode

        keys = pygame.key.get_pressed()

        # update game stats
        if state == STATE_PLAYING:
            player.move(keys)

            elapsed = current_time - start_time
            time_left_ms = game_duration - elapsed
            if time_left_ms <= 0:
                state = STATE_GAME_OVER

            wind = maybe_change_wind(wind, elapsed)

            spawn_interval = compute_spawn_interval(score)
            if current_time - last_spawn_time >= spawn_interval:
                max_birds = 3 + score // 50
                if len(birds) < max_birds:
                    bird_type = choose_bird_type(score)
                    direction = random.choice([-1, 1])
                    birds.append(Bird(bird_type, direction, wind))
                last_spawn_time = current_time

            for a in arrows:
                a.update()
            arrows = [a for a in arrows if a.alive]

            for b in birds:
                b.update()
            birds = [b for b in birds if b.alive]

            # Collisions
            for a in arrows:
                if not a.alive:
                    continue
                for bird in birds:
                    if bird.alive and a.rect().colliderect(bird.rect()):
                        a.alive = False
                        bird.alive = False
                        score += bird.points
                        break

            arrows = [a for a in arrows if a.alive]
            birds = [b for b in birds if b.alive]

        # drawing
        screen.fill(SKY)
        pygame.draw.rect(screen, GRASS, (0, int(HEIGHT * 0.75), WIDTH, int(HEIGHT * 0.25)))

        # Wind text
        if wind == -1:
            wind_text = FONT.render("Wind: <-", True, BLACK)
        elif wind == 1:
            wind_text = FONT.render("Wind: ->", True, BLACK)
        else:
            wind_text = FONT.render("Wind: calm", True, BLACK)
        screen.blit(wind_text, (10, 10))

        if state == STATE_MENU:
            title = BIG_FONT.render("Bird Game 3", True, BLACK)
            screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 80)))

            draw_button(start_button, "Start Game")
            draw_button(instructions_button, "Instructions")

            lb_title = FONT.render("Top 3 Leaderboard:", True, BLACK)
            screen.blit(lb_title, (WIDTH // 2 - 120, HEIGHT // 2 + 160))
            for i, entry in enumerate(leaderboard):
                line = FONT.render(f"{i + 1}. {entry['name']} - {entry['score']}", True, BLACK)
                screen.blit(line, (WIDTH // 2 - 120, HEIGHT // 2 + 190 + 25 * i))

        if state == STATE_INSTRUCTIONS:
            title = BIG_FONT.render("Instructions", True, RED)
            screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 150)))

            lines = [
                "Move bow with left and right arrows",
                "Aim with the mouse",
                "Click to shoot arrows",
                "Hit birds to gain points before time runs out",
                "Some birds have higher points",
                "Don't shoot too much, you'll lose points!",
                "Watch out, there is wind speed"
                "Credits: John and Evan CS10"
            ]

            for i, text in enumerate(lines):
                t = FONT.render(text, True, BLACK)
                screen.blit(t, (WIDTH // 2 - 260, HEIGHT // 2 - 70 + i * 30))

            draw_button(back_button, "Go Back")

        if state in (STATE_PLAYING, STATE_GAME_OVER):
            # Player, arrows, birds
            player.draw(screen)
            for a in arrows:
                a.draw(screen)
            for b in birds:
                b.draw(screen)

            # Score
            score_text = FONT.render(f"Score: {score}", True, BLACK)
            screen.blit(score_text, (10, 40))

            # Time (only while playing)
            if state == STATE_PLAYING:
                remaining = max(0, (game_duration - (current_time - start_time)) // 1000)
                time_text = FONT.render(f"Time: {remaining}", True, BLACK)
                screen.blit(time_text, (WIDTH - 150, 10))

            # Game over overlay
            if state == STATE_GAME_OVER:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 140))
                screen.blit(overlay, (0, 0))

                go_text = BIG_FONT.render("GAME OVER", True, WHITE)
                screen.blit(go_text, go_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 120)))

                info = FONT.render(f"Final Score: {score}", True, WHITE)
                screen.blit(info, info.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 70)))

                name_label = FONT.render("Insert your name and press enter:", True, WHITE)
                screen.blit(name_label, name_label.get_rect(center=(WIDTH // 2, HEIGHT // 2)))

                name_text = FONT.render(player_name, True, WHITE)
                screen.blit(name_text, name_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 30)))

                draw_button(restart_button, "Back to Menu")

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()